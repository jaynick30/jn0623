package com.jnickle.demos.ToolRentals.exceptions;

public class InvalidPercentageException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5060383377547367636L;

	public InvalidPercentageException(String errorMessage) {
		super(errorMessage);
	}
	
}
